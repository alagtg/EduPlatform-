
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Tresor.Api.Data;
using Tresor.Api.DTOs;
using Tresor.Api.Models;
using Tresor.Api.Services;

namespace Tresor.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _db; private readonly JwtService _jwt;
        public AuthController(AppDbContext db, JwtService jwt) { _db = db; _jwt = jwt; }

        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<ActionResult<LoginResponse>> Login(LoginRequest req)
        {
            var u = await _db.Users.FirstOrDefaultAsync(x => x.Username == req.Username);
            if (u is null) return Unauthorized();
            if (u.PasswordHash != Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(req.Password)))) return Unauthorized();
            var token = _jwt.CreateToken(u);
            return new LoginResponse { Token = token, Username = u.Username, Role = u.Role };
        }
    }
}
