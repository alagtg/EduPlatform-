
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tresor.Api.Data;
using Tresor.Api.DTOs;
using Tresor.Api.Models;

namespace Tresor.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly AppDbContext _db;
        public OrdersController(AppDbContext db) => _db = db;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Order>>> GetAll()
        {
            var orders = await _db.Orders.Include(o=>o.Items).ThenInclude(i=>i.Product).OrderByDescending(o=>o.CreatedAt).ToListAsync();
            return Ok(orders);
        }

        [HttpPost]
        public async Task<ActionResult<object>> Create(CreateOrderDto dto)
        {
            if (dto.Items.Count == 0) return BadRequest("Aucun article");
            var order = new Order { CustomerName=dto.CustomerName, Phone=dto.Phone, Address=dto.Address, Note=dto.Note };
            foreach (var it in dto.Items)
            {
                var product = await _db.Products.FindAsync(it.ProductId);
                if (product == null) return BadRequest($"Produit {it.ProductId} introuvable");
                if (product.Stock < it.Quantity) return BadRequest($"Stock insuffisant pour {product.Name}");
                product.Stock -= it.Quantity;
                order.Items.Add(new OrderItem{ ProductId=it.ProductId, Size=it.Size, Color=it.Color, Quantity=it.Quantity, UnitPrice=it.UnitPrice });
            }
            _db.Orders.Add(order);
            await _db.SaveChangesAsync();
            return Ok(new { message="Commande créée", orderId=order.Id, total=order.Total });
        }
    }
}
