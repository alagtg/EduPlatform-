export const environment = {
  "production": false,
  "apiBase": "http://localhost:5000/api",
  "whatsApp": "21650878068",
  "mapUrl": "https://maps.app.goo.gl/2KESYMRE7V8dmNfx8"
};
