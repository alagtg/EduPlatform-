export const environment = {
  "production": true,
  "apiBase": "/api",
  "whatsApp": "21650878068",
  "mapUrl": "https://maps.app.goo.gl/2KESYMRE7V8dmNfx8"
};
