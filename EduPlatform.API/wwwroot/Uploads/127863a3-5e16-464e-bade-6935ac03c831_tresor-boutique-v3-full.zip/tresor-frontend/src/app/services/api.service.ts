
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

export interface Product { id:number; name:string; description?:string; category:string; imageUrl?:string; price:number; stock:number; isPublished:boolean; }
export interface CreateOrderItem { productId:number; size:string; color:string; quantity:number; unitPrice:number; }
export interface CreateOrder { customerName:string; phone:string; address:string; note?:string; items: CreateOrderItem[]; }
export interface Expense { id?:number; label:string; amount:number; date:string; notes?:string; }

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  base = environment.apiBase;

  listProducts(published=true){ return this.http.get<Product[]>(`${this.base}/products?published=${published}`); }
  getProduct(id:number){ return this.http.get<Product>(`${this.base}/products/${id}`); }
  createOrder(o:CreateOrder){ return this.http.post(`${this.base}/orders`, o); }

  createProduct(p:any){ return this.http.post(`${this.base}/products`, p); }
  updateProduct(id:number, p:any){ return this.http.put(`${this.base}/products/${id}`, p); }
  deleteProduct(id:number){ return this.http.delete(`${this.base}/products/${id}`); }

  listExpenses(){ return this.http.get<any[]>(`${this.base}/expenses`); }
  addExpense(e:Expense){ return this.http.post(`${this.base}/expenses`, e); }
  deleteExpense(id:number){ return this.http.delete(`${this.base}/expenses/${id}`); }

  listOrders(){ return this.http.get<any[]>(`${this.base}/orders`); }
  summary(){ return this.http.get<any>(`${this.base}/dashboard/summary`); }
  chart(days=14){ return this.http.get<any[]>(`${this.base}/dashboard/chart?days=${days}`); }
}
