
import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiService, Product, CreateOrder } from '../../../services/api.service';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './product-detail.component.html'
})
export class ProductDetailComponent implements OnInit {
  private api = inject(ApiService);
  private route = inject(ActivatedRoute);
  product?: Product;
  size='M'; color='Beige'; qty=1;
  name=''; phone=''; address=''; note='';
  msg='';

  ngOnInit(){
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.api.getProduct(id).subscribe(p=> this.product=p);
  }

  buy(){
    if(!this.product){return;}
    const order: CreateOrder = {
      customerName: this.name || 'Visiteur',
      phone: this.phone || '21650878068',
      address: this.address || 'Djerba',
      note: this.note,
      items: [{ productId: this.product.id, size: this.size, color: this.color, quantity: this.qty, unitPrice: this.product.price }]
    };
    this.api.createOrder(order).subscribe({next:()=> this.msg='✅ Commande envoyée !', error:()=> this.msg='❌ Erreur.'});
  }
}
