
import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ApiService, Product } from '../../../services/api.service';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './product-list.component.html'
})
export class ProductListComponent implements OnInit {
  private api = inject(ApiService);
  products: Product[] = [];
  loading=true;
  ngOnInit(){ this.api.listProducts(true).subscribe({next:(d)=>{this.products=d;this.loading=false;}, error:()=>this.loading=false}); }
}
