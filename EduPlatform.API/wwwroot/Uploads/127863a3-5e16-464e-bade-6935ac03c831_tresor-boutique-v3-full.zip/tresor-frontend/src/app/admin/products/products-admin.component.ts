
import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService, Product } from '../../services/api.service';

@Component({
  selector: 'app-products-admin',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
  <div class="container" style="padding:16px 0">
    <h2>Produits</h2>
    <form (ngSubmit)="save()" #f="ngForm" class="card" style="padding:12px;margin-bottom:12px">
      <label>Nom <input [(ngModel)]="model.name" name="name"></label>
      <label>Prix <input type="number" [(ngModel)]="model.price" name="price"></label>
      <label>Stock <input type="number" [(ngModel)]="model.stock" name="stock"></label>
      <label>Catégorie <input [(ngModel)]="model.category" name="category"></label>
      <label>Image URL <input [(ngModel)]="model.imageUrl" name="imageUrl" placeholder="/uploads/xxx.jpg"></label>
      <label>Publier <input type="checkbox" [(ngModel)]="model.isPublished" name="isPublished"></label>
      <button class="btn" type="submit">Enregistrer</button>
      <span>{{msg}}</span>
    </form>

    <table>
      <thead><tr><th>Image</th><th>Nom</th><th>Prix</th><th>Stock</th><th>Actions</th></tr></thead>
      <tbody>
        <tr *ngFor="let p of products">
          <td><img [src]="p.imageUrl || 'assets/no-image.png'" style="height:56px"></td>
          <td>{{p.name}}</td><td>{{p.price}}</td><td>{{p.stock}}</td>
          <td><button class="btn" (click)="remove(p.id)">Supprimer</button></td>
        </tr>
      </tbody>
    </table>
  </div>
  `
})
export class ProductsAdminComponent implements OnInit {
  private api = inject(ApiService);
  products: Product[] = [];
  model:any = { name:'', price:0, stock:0, category:'Autre', isPublished:true, imageUrl:'' };
  msg='';

  ngOnInit(){ this.refresh(); }
  refresh(){ this.api.listProducts(false).subscribe(p=> this.products = p); }
  save(){ this.api.createProduct(this.model).subscribe({next:()=>{this.msg='✅ Produit créé'; this.refresh();}, error:()=> this.msg='❌ Erreur'}}); }
  remove(id:number){ this.api.deleteProduct(id).subscribe(()=> this.refresh()); }
}
