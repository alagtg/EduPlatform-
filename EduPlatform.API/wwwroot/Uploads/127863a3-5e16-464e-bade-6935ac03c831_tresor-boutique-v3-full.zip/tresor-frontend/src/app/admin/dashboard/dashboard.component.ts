
import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div class="container" style="padding:16px 0">
    <h2 style="font-family:'Playfair Display',serif">Dashboard</h2>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px">
      <div class="card" style="padding:12px"><strong>CA du jour</strong><div>{{summary?.caJour}} TND</div></div>
      <div class="card" style="padding:12px"><strong>CA du mois</strong><div>{{summary?.caMois}} TND</div></div>
      <div class="card" style="padding:12px"><strong>Dépenses mois</strong><div>{{summary?.depensesMois}} TND</div></div>
      <div class="card" style="padding:12px"><strong>Bénéfice net</strong><div>{{summary?.beneficeNet}} TND</div></div>
    </div>
  </div>
  `
})
export class DashboardComponent implements OnInit {
  private api = inject(ApiService);
  summary:any;
  ngOnInit(){ this.api.summary().subscribe(s => this.summary = s); }
}
