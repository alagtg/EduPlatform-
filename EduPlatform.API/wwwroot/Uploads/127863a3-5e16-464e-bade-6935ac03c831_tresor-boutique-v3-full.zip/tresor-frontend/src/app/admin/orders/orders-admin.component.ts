
import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-orders-admin',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div class="container" style="padding:16px 0">
    <h2>Commandes</h2>
    <table>
      <thead><tr><th>Date</th><th>Client</th><th>Items</th><th>Total</th></tr></thead>
      <tbody>
        <tr *ngFor="let o of orders">
          <td>{{o.createdAt | date:'short'}}</td>
          <td>{{o.customerName}} ({{o.phone}})</td>
          <td>
            <div *ngFor="let i of o.items">{{i.product?.name}} x{{i.quantity}} ({{i.size}} {{i.color}})</div>
          </td>
          <td>{{o.items?.reduce((s:number,i:any)=> s + i.unitPrice*i.quantity, 0)}}</td>
        </tr>
      </tbody>
    </table>
  </div>
  `
})
export class OrdersAdminComponent implements OnInit {
  private api = inject(ApiService);
  orders:any[]=[];
  ngOnInit(){ this.api.listOrders().subscribe(d=> this.orders = d); }
}
