
import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-expenses',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
  <div class="container" style="padding:16px 0">
    <h2>Dépenses</h2>
    <form (ngSubmit)="add()" class="card" style="padding:12px;margin-bottom:12px">
      <label>Libellé <input [(ngModel)]="label" name="label"></label>
      <label>Montant (ex: -50) <input type="number" [(ngModel)]="amount" name="amount"></label>
      <label>Date <input type="date" [(ngModel)]="date" name="date"></label>
      <label>Notes <input [(ngModel)]="notes" name="notes"></label>
      <button class="btn" type="submit">Ajouter</button>
    </form>
    <table>
      <thead><tr><th>Date</th><th>Libellé</th><th>Montant</th><th></th></tr></thead>
      <tbody>
        <tr *ngFor="let e of items">
          <td>{{e.date | date}}</td><td>{{e.label}}</td><td>{{e.amount}}</td>
          <td><button class="btn" (click)="del(e.id)">Supprimer</button></td>
        </tr>
      </tbody>
    </table>
  </div>
  `
})
export class ExpensesComponent implements OnInit {
  private api = inject(ApiService);
  items:any[]=[]; label=''; amount=-10; date = new Date().toISOString().substring(0,10); notes='';

  ngOnInit(){ this.load(); }
  load(){ this.api.listExpenses().subscribe(d=> this.items=d); }
  add(){
    this.api.addExpense({label:this.label, amount:this.amount, date:this.date, notes:this.notes}).subscribe(()=>{
      this.label=''; this.amount=-10; this.notes=''; this.load();
    });
  }
  del(id:number){ this.api.deleteExpense(id).subscribe(()=> this.load()); }
}
