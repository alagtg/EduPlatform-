
import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
  <div class="container" style="max-width:420px;padding:40px 16px">
    <h2>Admin – Connexion</h2>
    <p>Version simplifiée (JWT côté API prêt). Ajout complet du login lors de l'étape suivante.</p>
    <a routerLink="/admin">Entrer au Dashboard</a>
  </div>
  `
})
export class LoginComponent {}
