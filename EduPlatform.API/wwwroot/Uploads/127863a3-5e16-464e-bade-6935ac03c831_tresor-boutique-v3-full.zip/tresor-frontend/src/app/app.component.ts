
import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink],
  template: `
  <div class="top"><div class="container">
    <nav>
      <a routerLink="/" style="font-family:'Playfair Display',serif;font-size:22px">Trésor Boutique</a>
      <div>
        <a routerLink="/" style="margin-right:12px">Accueil</a>
        <a routerLink="/contact" style="margin-right:12px">Contact</a>
        <a routerLink="/admin" class="btn">Admin</a>
      </div>
    </nav></div>
  </div>
  <router-outlet></router-outlet>
  <footer style="margin-top:40px;border-top:2px solid var(--beige);background:#fff">
    <div class="container" style="padding:18px 0">© 2025 Trésor Boutique – Djerba</div>
  </footer>`
})
export class AppComponent {}
