
import { bootstrapApplication } from '@angular/platform-browser';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter, Routes } from '@angular/router';
import { AppComponent } from './app/app.component';
import { ProductListComponent } from './app/client/pages/product-list/product-list.component';
import { ProductDetailComponent } from './app/client/pages/product-detail/product-detail.component';
import { ContactComponent } from './app/client/pages/contact/contact.component';
import { LoginComponent } from './app/admin/login/login.component';
import { DashboardComponent } from './app/admin/dashboard/dashboard.component';
import { ProductsAdminComponent } from './app/admin/products/products-admin.component';
import { ExpensesComponent } from './app/admin/expenses/expenses.component';
import { OrdersAdminComponent } from './app/admin/orders/orders-admin.component';

const routes: Routes = [
  { path: '', component: ProductListComponent },
  { path: 'produit/:id', component: ProductDetailComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'admin/login', component: LoginComponent },
  { path: 'admin', component: DashboardComponent },
  { path: 'admin/produits', component: ProductsAdminComponent },
  { path: 'admin/depenses', component: ExpensesComponent },
  { path: 'admin/commandes', component: OrdersAdminComponent },
];

bootstrapApplication(AppComponent, {
  providers: [provideHttpClient(), provideRouter(routes)],
}).catch(err => console.error(err));
