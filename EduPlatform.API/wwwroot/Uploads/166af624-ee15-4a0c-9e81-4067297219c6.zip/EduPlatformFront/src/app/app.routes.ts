import { Routes } from '@angular/router';
import { ProfLoginComponent } from './pages/prof-login/prof-login.component';
import { ProfDashboardComponent } from './pages/prof-dashboard/prof-dashboard.component';
import { ProfPublicComponent } from './pages/prof-public/prof-public.component';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  { path: 'prof/:slug', component: ProfPublicComponent },
  { path: ':slug', component: ProfPublicComponent },
  { path: 'login', component: ProfLoginComponent },
  { path: 'dashboard', component: ProfDashboardComponent, canActivate: [authGuard] },
  { path: '', redirectTo: 'prof/mme-houda', pathMatch: 'full' },
  { path: '**', redirectTo: 'prof/mme-houda' }
];
