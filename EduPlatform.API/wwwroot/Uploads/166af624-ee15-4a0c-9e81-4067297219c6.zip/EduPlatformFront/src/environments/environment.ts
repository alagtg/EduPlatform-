export const environment = {
  production: false,
  apiUrl: 'https://localhost:7043/api'
};
