export const environment = {
  production: true,
  apiUrl: 'https://localhost:7043/api'
};
